Setup


All you need to do is run the main.py and it should work, if not do 
pip install pygame
pip install sys
pip install time 
In the commmand prompt


















_____________________________________________________________________________________________
CUSTOMIZING


If you want your own image instead of my logo edit the intro_ball file to whatever image you want.